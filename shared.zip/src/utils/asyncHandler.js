// backend/src/utils/asyncHandler.js
export const ah = fn => (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next)
